# ----------------------------------------------------------
# Program: Check if three sides form a triangle and its type
# ----------------------------------------------------------

class TriangleChecker:
    def __init__(self, side1, side2, side3):
        # Initialize sides of the triangle
        self.side1 = side1
        self.side2 = side2
        self.side3 = side3

    def is_valid_triangle(self):
        """
        Check if the three sides can form a valid triangle.
        Triangle Inequality Theorem:
        Sum of any two sides must be greater than the third side.
        """
        return (self.side1 + self.side2 > self.side3) and                (self.side1 + self.side3 > self.side2) and                (self.side2 + self.side3 > self.side1)

    def triangle_type(self):
        """
        Determine the type of triangle:
        - Equilateral: All sides are equal
        - Isosceles: Two sides are equal
        - Scalene: All sides are different
        """
        if self.side1 == self.side2 == self.side3:
            return "Equilateral Triangle"
        elif self.side1 == self.side2 or self.side2 == self.side3 or self.side1 == self.side3:
            return "Isosceles Triangle"
        else:
            return "Scalene Triangle"


# ----------------- Main Program -----------------
# Taking user input
side1 = float(input("Enter length of first side: "))
side2 = float(input("Enter length of second side: "))
side3 = float(input("Enter length of third side: "))

# Create an object of TriangleChecker
triangle = TriangleChecker(side1, side2, side3)

# Check and display the result
if triangle.is_valid_triangle():
    print("✅ The sides form a triangle.")
    print("🔹 Type of Triangle:", triangle.triangle_type())
else:
    print("❌ The given sides do not form a triangle.")
