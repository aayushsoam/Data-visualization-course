# Program 3: Count number of lines in the given file
file_name = "data.txt"

with open(file_name, "r") as file:
    lines = file.readlines()

print("Number of lines:", len(lines))
