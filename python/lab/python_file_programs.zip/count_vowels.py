# Program 2: Count number of vowels in the given file
file_name = "data.txt"
vowels = "aeiouAEIOU"
count = 0

with open(file_name, "r") as file:
    text = file.read()
    for ch in text:
        if ch in vowels:
            count += 1

print("Number of vowels:", count)
