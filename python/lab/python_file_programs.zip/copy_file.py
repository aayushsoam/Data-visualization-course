# Program 1: Copy data from one file into another file
source_file = "source.txt"
destination_file = "destination.txt"

with open(source_file, "r") as src:
    data = src.read()

with open(destination_file, "w") as dest:
    dest.write(data)

print("Data copied successfully from source.txt to destination.txt")
