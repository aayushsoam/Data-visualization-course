# Program 4: Count number of characters in the given file
file_name = "data.txt"

with open(file_name, "r") as file:
    text = file.read()

print("Number of characters:", len(text))
